package com.example.cadastrocartoes12300233


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cadastrocartoes12300233.database.AppDatabase
import com.example.cadastrocartoes12300233.dao.CartaoDao
import com.example.cadastrocartoes12300233.model.CartaoModel

class MainActivity : AppCompatActivity() {

    private lateinit var etCardNumber: EditText
    private lateinit var etCardHolder: EditText
    private lateinit var etExpiry: EditText
    private lateinit var etCvv: EditText
    private lateinit var btnSave: Button

    private lateinit var db: AppDatabase
    private lateinit var cartaoDao: CartaoDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializando views
        etCardNumber = findViewById(R.id.etCardNumber)
        etCardHolder = findViewById(R.id.etCardHolder)
        etExpiry = findViewById(R.id.etExpiry)
        etCvv = findViewById(R.id.etCvv)
        btnSave = findViewById(R.id.btnSave)

        // Inicializando banco de dados
        db = AppDatabase.getInstance(this)
        cartaoDao = db.cartaoDao()

        // Ação do botão Salvar
        btnSave.setOnClickListener {
            salvarCartao()
        }
    }

    private fun salvarCartao() {
        val numero = etCardNumber.text.toString().trim()
        val titular = etCardHolder.text.toString().trim()
        val validade = etExpiry.text.toString().trim()
        val cvv = etCvv.text.toString().trim()

        // Validação simples
        if (numero.isEmpty() || titular.isEmpty() || validade.isEmpty() || cvv.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            return
        }

        if (cvv.length != 3) {
            Toast.makeText(this, "CVV deve ter 3 dígitos!", Toast.LENGTH_SHORT).show()
            return
        }

        // Criando o objeto CartaoModel
        val cartao = CartaoModel().apply {
            this.numero_cartao = numero
            this.titular = titular
            this.data_vencimento = validade
            this.cvv = cvv
        }

        // Inserindo no banco de dados
        Thread {
            try {
                val id = cartaoDao.insertCartao(cartao)
                runOnUiThread {
                    if (id != -1L) {
                        Toast.makeText(this, "Cartão salvo com sucesso!", Toast.LENGTH_SHORT).show()
                        limparCampos()
                    } else {
                        Toast.makeText(this, "Erro ao salvar cartão.", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun limparCampos() {
        etCardNumber.text.clear()
        etCardHolder.text.clear()
        etExpiry.text.clear()
        etCvv.text.clear()
    }
}