package com.example.cadastrocartoes12300233.model



import androidx.room.*
import androidx.room.Entity

@Entity(tableName = "TB_CARTAO")
class CartaoModel {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_cartao")
    var id_cartao: Int = 0

    @ColumnInfo(name = "numero_cartao")
    var numero_cartao: String = ""

    @ColumnInfo(name = "titular")
    var titular: String = ""

    @ColumnInfo(name = "cvv")
    var cvv: String = ""

    @ColumnInfo(name = "data_vencimento")
    var data_vencimento: String = ""
}