package com.example.cadastrocartoes12300233.dao



import androidx.room.*

import com.example.cadastrocartoes12300233.model.CartaoModel

@Dao
interface CartaoDao {

    @Insert
    fun insertCartao(cartao: CartaoModel): Long

    @Update
    fun updateCartao(cartao: CartaoModel): Int

    @Delete
    fun deleteCartao(cartao: CartaoModel): Int

    @Query("SELECT * FROM TB_CARTAO WHERE id_cartao = :id")
    fun get(id: Int): CartaoModel

    @Query("SELECT * FROM TB_CARTAO")
    fun getAll(): List<CartaoModel>
}