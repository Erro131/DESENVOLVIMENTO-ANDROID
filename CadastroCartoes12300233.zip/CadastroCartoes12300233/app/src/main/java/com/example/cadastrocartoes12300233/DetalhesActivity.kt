package com.example.cadastrocartoes12300233


import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cadastrocartoes12300233.database.AppDatabase
import com.example.cadastrocartoes12300233.dao.CartaoDao
import com.example.cadastrocartoes12300233.model.CartaoModel

class DetalhesActivity : AppCompatActivity() {

    private lateinit var tvCardNumber: TextView
    private lateinit var tvCardHolder: TextView
    private lateinit var tvExpiry: TextView
    private lateinit var tvCvv: TextView

    private lateinit var db: AppDatabase
    private lateinit var cartaoDao: CartaoDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhes)

        tvCardNumber = findViewById(R.id.tvCardNumber)
        tvCardHolder = findViewById(R.id.tvCardHolder)
        tvExpiry = findViewById(R.id.tvExpiry)
        tvCvv = findViewById(R.id.tvCvv)

        db = AppDatabase.getInstance(this)
        cartaoDao = db.cartaoDao()

        val cartaoId = intent.getIntExtra("CARTAO_ID", -1)
        if (cartaoId == -1) {
            Toast.makeText(this, "Erro ao carregar cartão.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        Thread {
            try {
                val cartao = cartaoDao.get(cartaoId)
                runOnUiThread {
                    exibirDetalhes(cartao)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }.start()
    }

    private fun exibirDetalhes(cartao: CartaoModel) {
        tvCardNumber.text = "Número: ${cartao.numero_cartao}"
        tvCardHolder.text = "Titular: ${cartao.titular}"
        tvExpiry.text = "Validade: ${cartao.data_vencimento}"
        tvCvv.text = "CVV: ${cartao.cvv}"
    }
}